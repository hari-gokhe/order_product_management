package com.orderproductmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderproductmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderproductmanagementApplication.class, args);
	}

}
