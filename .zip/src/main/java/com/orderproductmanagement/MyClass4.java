package com.orderproductmanagement;

public class MyClass4 {
  public static void main(String[] args) {
	MyClass1 m1 = new MyClass1();
	m1.method1();
}
}
