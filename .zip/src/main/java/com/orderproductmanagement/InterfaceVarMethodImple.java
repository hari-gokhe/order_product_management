package com.orderproductmanagement;



public class InterfaceVarMethodImple {
	
	
	public static void main(String[] args) {
		
	}
}
