package com.orderproductmanagement;

public class MyClass1 {
	
	protected void method1() {
		
	}

}
