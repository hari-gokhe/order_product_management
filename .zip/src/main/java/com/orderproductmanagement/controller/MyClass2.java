package com.orderproductmanagement.controller;

import java.io.Externalizable;

import com.orderproductmanagement.MyClass1;

public class MyClass2 extends MyClass1 {
	
	public static void main(String[] args) {
		
	}

}
